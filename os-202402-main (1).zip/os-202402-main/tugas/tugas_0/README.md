#masuk ke directory, ekstrax file ziptuliskan kode berikut:

```
docker build -t praktikum-os1234 .
```
setelah proses eksekusi command berikut:
```
docker run -it --name praktikum-os1234 praktikum-os1234
```
